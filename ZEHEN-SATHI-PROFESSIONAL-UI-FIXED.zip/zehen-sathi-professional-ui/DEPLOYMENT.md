# ZEHEN SATHI AI — deployment notes

## Required Vercel environment variables
- `OPENROUTER_API_KEY` — required by `/api/chat`
- `PI_API_KEY` — required by `/api/payment/approve` and `/api/payment/complete`

Set these in Vercel Project Settings → Environment Variables, then redeploy.

## Important
- Open the app inside Pi Browser for Pi SDK sign-in and Pi payments.
- The frontend uses `/Auth.js` for Pi authentication/payment callbacks and `/Script.js` for chat.
- Backend endpoints are under `/api/`: `/api/auth`, `/api/chat`, `/api/payment/approve`, `/api/payment/complete`.
- Never commit secret API keys to GitHub. Keep them in Vercel Environment Variables.
- This ZIP has been statically inspected; live Pi Network and OpenRouter requests still require deployment credentials and testing in Pi Browser.
